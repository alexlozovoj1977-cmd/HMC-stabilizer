# EGM Stabilizer

Minimal repo.
DOI-ready.